import os
import streamlit as st
from dotenv import load_dotenv
from groq import Groq

# Load environment variables
load_dotenv()

# Get Groq API key
api_key = os.getenv("GROQ_API_KEY")

# Check API key
if not api_key:
    st.error("GROQ_API_KEY not found. Please create a .env file.")
    st.stop()

# Create Groq client
client = Groq(api_key=api_key)

# Page configuration
st.set_page_config(
    page_title="Groq AI Chatbot",
    page_icon="AI",
    layout="centered"
)

st.title("Groq AI Chatbot")
st.write("Ask anything and get a response from the Groq LLM.")

# Initialize chat history
if "messages" not in st.session_state:
    st.session_state.messages = [
        {
            "role": "system",
            "content": "You are a helpful AI assistant. Give clear and concise answers."
        }
    ]

# Display previous messages
for message in st.session_state.messages:
    if message["role"] != "system":
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

# Chat input
user_prompt = st.chat_input("Type your question here...")

if user_prompt:

    # Display user message
    with st.chat_message("user"):
        st.markdown(user_prompt)

    # Add user message to history
    st.session_state.messages.append(
        {
            "role": "user",
            "content": user_prompt
        }
    )

    # Generate AI response
    with st.chat_message("assistant"):

        try:
            response = client.chat.completions.create(
                model="openai/gpt-oss-120b",
                messages=st.session_state.messages,
                temperature=0.7,
                max_tokens=1000
            )

            ai_response = response.choices[0].message.content

            st.markdown(ai_response)

            # Store AI response
            st.session_state.messages.append(
                {
                    "role": "assistant",
                    "content": ai_response
                }
            )

        except Exception as e:
            st.error(f"Error: {e}")